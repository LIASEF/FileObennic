#sublime-sourcetrail

The Sublime plugin is hosted at GitHub.

Link to the repository: [sublime-sourcetrail](https://github.com/CoatiSoftware/sublime-sourcetrail).
