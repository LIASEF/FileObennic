#eclipse-sourcetrail

The Eclipse plugin is hosted at GitHub.

Link to the repository: [eSourcetrail](https://github.com/CoatiSoftware/eSourcetrail).
