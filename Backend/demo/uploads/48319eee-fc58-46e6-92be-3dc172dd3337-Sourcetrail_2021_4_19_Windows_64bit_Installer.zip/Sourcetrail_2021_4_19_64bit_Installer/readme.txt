=====================
||Sourcetrail Setup||
=====================

To install Sourcetrail simply run 'sourcetrail.msi'

Note: If you have a previous version installed, sourcetrail.msi will attempt 
to upgrade. Your previous application specific settings will be maintained.
