#qtc-sourcetrail

The QtCreator plugin is hosted at GitHub.

Link to the repository: [qtc-sourcetrail](https://github.com/CoatiSoftware/qtc-sourcetrail).



