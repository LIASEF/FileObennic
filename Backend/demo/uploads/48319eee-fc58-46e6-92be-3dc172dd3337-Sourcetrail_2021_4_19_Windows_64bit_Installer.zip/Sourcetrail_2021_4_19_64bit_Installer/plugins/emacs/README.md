#emacs-sourcetrail

The Emacs plugin is hosted at GitHub.

Link to the repository: [emacs-sourcetrail](https://github.com/CoatiSoftware/emacs-sourcetrail).
